from django import forms
from .models import Usuario

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario  # Especifique o modelo com o qual este formulário está associado
        fields = '__all__'  # Isso incluirá todos os campos do modelo no formulário

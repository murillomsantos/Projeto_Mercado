from django.shortcuts import render, redirect
from .models import Usuario
from .forms import UsuarioForm  # Certifique-se de que você importou o formulário corretamente
from django.middleware.csrf import get_token  # Importe o método get_token

def home(request):
    return render(request, 'usuarios/home.html')

def criar_usuario(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        print("Antes de verificar se o formulário é válido")
        if form.is_valid():
            print("O formulário é válido")
            form.save()
            return redirect('listagem_usuarios')
        else:
            print("O formulário não é válido")
    else:
        form = UsuarioForm()

    usuarios = {
       'usuarios': Usuario.objects.all()
    }

    context = {
        'usuarios': usuarios,
        'form': form,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/usuarios.html', context)

def lista_usuarios(request):
    tipo_pesquisa = request.GET.get('tipo_pesquisa')
    valor_pesquisa = request.GET.get('valor_pesquisa')

    usuarios = []

    if tipo_pesquisa == 'id':
        try:
            usuario = Usuario.objects.get(pk=valor_pesquisa)
            usuarios.append(usuario)
        except Usuario.DoesNotExist:
            pass
    elif tipo_pesquisa == 'nome':
        usuarios = Usuario.objects.filter(nome__icontains=valor_pesquisa)
    elif tipo_pesquisa == 'cpf':
        usuarios = Usuario.objects.filter(cpf=valor_pesquisa)
    elif tipo_pesquisa == 'telefone':
        usuarios = Usuario.objects.filter(telefone=valor_pesquisa)
    else:
        usuarios = Usuario.objects.all()

    context = {
        'usuarios': usuarios,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/usuarios.html', context)

def editar_usuario(request, usuario_id):
    usuario = get_object_or_404(Usuario, pk=usuario_id)

    if request.method == 'POST':
        form = UsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            return redirect('listagem_usuarios')
    else:
        form = UsuarioForm(instance=usuario)

    context = {
        'form': form,
        'usuario': usuario,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/editar_usuario.html', context)

from django.urls import path
from app_cad_user import views

urlpatterns = [
    path('', views.home, name='home'),
    path('usuarios/', views.lista_usuarios, name='listagem_usuarios'),
    path('criar_usuario/', views.criar_usuario, name='criar_usuario'),  # Rota para criar usuário
    path('editar_usuario/<int:usuario_id>/', views.editar_usuario, name='editar_usuario'),
]

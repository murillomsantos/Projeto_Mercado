from django.urls import path
from app_cad_user import views

urlpatterns = [
    path('', views.home, name='home'),
    path('usuarios/', views.lista_usuarios, name='listagem_usuarios'),
    path('criar_usuario/', views.criar_usuario, name='criar_usuario'),  # Rota para criar usuário
    path('editar_usuario/<int:usuario_id>/', views.editar_usuario, name='editar_usuario'),
    path('cadastrar_produto/', views.cadastrar_produto, name='cadastrar_produto'),
    path('test_db_connection/', views.test_db_connection, name='test_db_connection'),
    path('produtos/', views.lista_produtos, name='listagem_produtos'),
    path('editar_produto/<int:produto_id>/', views.editar_produto, name='editar_produto'),
]


from django.shortcuts import render, redirect, get_object_or_404
from .models import Usuario
from .forms import UsuarioForm  # Certifique-se de que você importou o formulário corretamente
from django.middleware.csrf import get_token  # Importe o método get_token
from .forms import ProdutoForm
import logging
from django.db import connection
from django.http import HttpResponse
from .models import Produto


def home(request):
    return render(request, 'usuarios/home.html')

def criar_usuario(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        print("Antes de verificar se o formulário é válido")
        if form.is_valid():
            print("O formulário é válido")
            form.save()
            return redirect('listagem_usuarios')
        else:
            print("O formulário não é válido")
    else:
        form = UsuarioForm()

    usuarios = {
       'usuarios': Usuario.objects.all()
    }

    context = {
        'usuarios': usuarios,
        'form': form,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/usuarios.html', context)

def lista_usuarios(request):
    tipo_pesquisa = request.GET.get('tipo_pesquisa')
    valor_pesquisa = request.GET.get('valor_pesquisa')

    usuarios = []

    if tipo_pesquisa == 'id':
        try:
            usuario = Usuario.objects.get(pk=valor_pesquisa)
            usuarios.append(usuario)
        except Usuario.DoesNotExist:
            pass
    elif tipo_pesquisa == 'nome':
        usuarios = Usuario.objects.filter(nome__icontains=valor_pesquisa)
    elif tipo_pesquisa == 'cpf':
        usuarios = Usuario.objects.filter(cpf=valor_pesquisa)
    elif tipo_pesquisa == 'telefone':
        usuarios = Usuario.objects.filter(telefone=valor_pesquisa)
    else:
        usuarios = Usuario.objects.all()

    context = {
        'usuarios': usuarios,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/usuarios.html', context)

def editar_usuario(request, usuario_id):
    usuario = get_object_or_404(Usuario, pk=usuario_id)

    if request.method == 'POST':
        form = UsuarioForm(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            return redirect('listagem_usuarios')
    else:
        form = UsuarioForm(instance=usuario)

    context = {
        'form': form,
        'usuario': usuario,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'usuarios/editar_usuario.html', context)


def cadastrar_produto(request):
    if request.method == 'POST':
        form = ProdutoForm(request.POST)
        if form.is_valid():
            form.save()
            logging.debug('Produto salvo com sucesso!')  # Mensagem de depuração
            return redirect('listagem_produtos')
        else:
            logging.debug('Formulário inválido: %s' % form.errors)  # Mensagem de depuração
    else:
        form = ProdutoForm()

    context = {'form': form}
    return render(request, 'produtos/cadastrar_produto.html', context)

def test_db_connection(request):
    try:
        connection.ensure_connection()
        return HttpResponse("Conexão com o banco de dados bem-sucedida.")
    except DatabaseError as e:
        return HttpResponse("Erro de conexão com o banco de dados: %s" % str(e))

def lista_produtos(request):
    tipo_pesquisa = request.GET.get('tipo_pesquisa')
    valor_pesquisa = request.GET.get('valor_pesquisa')

    produtos = []

    if tipo_pesquisa == 'id':
        try:
            produto = Produto.objects.get(pk=valor_pesquisa)
            produtos.append(produto)
        except Produto.DoesNotExist:
            pass
    elif tipo_pesquisa == 'nome':
        produtos = Produto.objects.filter(nome__icontains=valor_pesquisa)
    elif tipo_pesquisa == 'descricao':
        produtos = Produto.objects.filter(descricao=valor_pesquisa)
    elif tipo_pesquisa == 'preco':
        produtos = Produto.objects.filter(preco=valor_pesquisa)
    else:
        produtos = Produto.objects.all()

    context = {
        'produtos': produtos,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'produtos/produtos.html', context)

def editar_produto(request, produto_id):
    produto = get_object_or_404(Produto, pk=produto_id)

    if request.method == 'POST':
        form = ProdutoForm(request.POST, instance=produto)
        if form.is_valid():
            form.save()
            return redirect('listagem_produtos')
    else:
        form = ProdutoForm(instance=produto)

    context = {
        'form': form,
        'produto': produto,
        'csrf_token': get_token(request),  # Adicione esta linha para incluir o token CSRF
    }

    return render(request, 'produtos/editar_produto.html', context)



from django import forms
from .models import Usuario
from .models import Produto

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario  # Especifique o modelo com o qual este formulário está associado
        fields = '__all__'  # Isso incluirá todos os campos do modelo no formulário

class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = '__all__'
    preco = forms.DecimalField(max_digits=10, decimal_places=2)

        